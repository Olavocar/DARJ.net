<?php 
$con = mysqli_connect('srv951.hstgr.io', 'u329497034_daarearj', '2die4100@@A2', 'u329497034_daarearj');
?>