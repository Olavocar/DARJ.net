<?php 
$con = mysqli_connect('db4free.net:3306', 'volaodarj', '26ec018b', 'daarearj');
?>